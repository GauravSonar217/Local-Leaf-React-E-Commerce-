import React, { Component } from 'react'
import Login from './Components/Login'
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword  } from "firebase/auth";
import Register from './Components/Register';


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAG_rl_niz6HPrWZZmo0_oY6siaqFAFrPo",
  authDomain: "course-survey-1a3d9.firebaseapp.com",
  databaseURL: "https://course-survey-1a3d9-default-rtdb.firebaseio.com",
  projectId: "course-survey-1a3d9",
  storageBucket: "course-survey-1a3d9.appspot.com",
  messagingSenderId: "281157725548",
  appId: "1:281157725548:web:56ada465ca5dd0361a5749"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();


export default class App extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       isShown:false,
       message:"Password Confirm"
    }
  }
  accountHandler=()=>{
    this.setState({isShown:true})
  }

  loginHandler=(event)=>{
    this.setState({isShown:false})
    event.preventDefault();
    const email=event.target.email.value;
    const pass=event.target.password.value;
    

  signInWithEmailAndPassword(auth, email, pass)
  .then((userCredential) => {
    const user = userCredential.user;
    console.log(user)
  })
  .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    console.log(errorCode,errorMessage)
  });
  }
  registrationHandler=(event)=>
  {
    event.preventDefault();
    const email=event.target.email.value;
    const pass=event.target.password.value;
    const cnfp=event.target.cnfpassword.value;
    if(pass!==cnfp)
    {
      this.setState({message:"Password did not match"})
      return
    }
    
   const apro = createUserWithEmailAndPassword(auth, email, pass);

    apro.then((userCredential) => {
        const user = userCredential.user;
        console.log(user)
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.log(errorCode, errorMessage)
      });
    

  }
  render() {
    return (
      <div className='container'>
        <h2>Registration</h2>
        { !this.state.isShown ? <Login  submit={this.accountHandler} login={this.loginHandler} /> : <Register submit={this.loginHandler} msg={this.state.message} register={this.registrationHandler}/> }
      </div>
    )
  }
}
