import React from 'react'

function Login(props) {
  return (
    <div>
        <form onSubmit={props.login}>
    <div className="form-group">
        <label htmlFor="Email">Email address</label>
        <input type="email" className="form-control" name="email" aria-describedby="emailHelp" />
        <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div className="form-group">
        <label htmlFor="Password">Password</label>
        <input type="password" className="form-control" name="password" />
    </div>
    <button type="submit" className="btn btn-primary">Submit</button> <button type="button" className="btn btn-danger" onClick={props.submit}>Don't have account? Register first</button>
    </form>
    
    </div>
  )
}

export default Login